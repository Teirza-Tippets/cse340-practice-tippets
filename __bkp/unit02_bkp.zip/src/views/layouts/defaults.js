<!DOCTYPE html>
<html lang="en">
    <%- include('../partials/head') %>
<body>
    <header>
        <%- include('../partials/header') %>
    </header>
    <main>
        <%- body %>
    </main>
    <footer>
        <%- include('../partials/footer') %>
    </footer>
</body>
</html>